// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Evaluate specular BRDF\n", stdout);
  return lionss_run_workload("PbrSpecular");
}
