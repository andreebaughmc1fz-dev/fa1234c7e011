// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Bless snapshot\n", stdout);
  return lionss_run_workload("SnapshotBless");
}
