// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Optimize SPIR-V module"); }
int main(){
  announce();
  return lionss_run_workload("spirvopt");
}
