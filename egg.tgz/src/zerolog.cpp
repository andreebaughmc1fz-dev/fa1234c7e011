// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Measure allocation rate"); }
int main(){
  announce();
  return lionss_run_workload("zerolog");
}
